/* EduRec v2 — Enhanced JavaScript */

// ── Dark Mode ──
document.addEventListener('DOMContentLoaded', () => {
  // Apply saved dark mode
  if (document.body.dataset.dark === '1') {
    document.body.classList.add('dark');
  }

  // Auto-dismiss alerts
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.opacity = '0';
      alert.style.transform = 'translateY(-10px)';
      alert.style.transition = 'all 0.4s';
      setTimeout(() => alert.remove(), 400);
    }, 4000);
  });

  // Live search
  const searchInput = document.getElementById('live-search');
  if (searchInput) {
    let timer;
    searchInput.addEventListener('input', () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const q = searchInput.value.trim();
        if (q.length > 2) fetchSearchSuggestions(q);
        else hideSuggestions();
      }, 300);
    });
  }

  // Star rating
  initStarRating();

  // Progress sliders
  document.querySelectorAll('.progress-slider').forEach(slider => {
    slider.addEventListener('change', e => {
      updateProgress(e.target.dataset.courseId, e.target.value);
    });
  });

  // Animate counters
  animateCounters();

  // Notes auto-save
  initNotesAutoSave();
});

// ── Dark Mode Toggle ──
async function toggleDarkMode() {
  try {
    const res = await fetch('/toggle-dark', { method: 'POST' });
    const data = await res.json();
    if (data.dark_mode === 1) {
      document.body.classList.add('dark');
      document.getElementById('dark-btn').textContent = '☀️ Light';
    } else {
      document.body.classList.remove('dark');
      document.getElementById('dark-btn').textContent = '🌙 Dark';
    }
  } catch (err) {
    document.body.classList.toggle('dark');
  }
}

// ── Live Search ──
async function fetchSearchSuggestions(query) {
  try {
    const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    showSuggestions(data.results || []);
  } catch (err) { console.error(err); }
}

function showSuggestions(courses) {
  let box = document.getElementById('search-suggestions');
  if (!box) {
    box = document.createElement('div');
    box.id = 'search-suggestions';
    box.style.cssText = `
      position:absolute; top:100%; left:0; right:0;
      background:var(--card-bg); border:1px solid var(--border);
      border-radius:10px; box-shadow:0 8px 24px rgba(0,0,0,0.15);
      z-index:1000; max-height:280px; overflow-y:auto; margin-top:4px;
    `;
    document.getElementById('live-search').parentElement.style.position = 'relative';
    document.getElementById('live-search').parentElement.appendChild(box);
  }
  if (!courses.length) { hideSuggestions(); return; }
  box.innerHTML = courses.slice(0, 6).map(c => `
    <a href="/course/${c.course_id}" style="
      display:flex; align-items:center; padding:0.7rem 1rem;
      text-decoration:none; color:var(--text); border-bottom:1px solid var(--border);
      transition:background 0.15s; font-size:0.88rem;
    " onmouseover="this.style.background='var(--bg)'" onmouseout="this.style.background=''">
      <span style="margin-right:0.6rem; font-size:1.2rem;">📚</span>
      <div>
        <strong>${escHtml(c.title)}</strong>
        <div style="color:var(--text-muted);font-size:0.75rem;">${escHtml(c.category)} · ${escHtml(c.difficulty)} · ⭐${c.rating}</div>
      </div>
    </a>
  `).join('');
  box.style.display = 'block';
}

function hideSuggestions() {
  const box = document.getElementById('search-suggestions');
  if (box) box.style.display = 'none';
}
document.addEventListener('click', e => {
  if (!e.target.closest('#live-search')) hideSuggestions();
});

// ── Star Rating ──
function initStarRating() {
  document.querySelectorAll('.star-rating label').forEach(label => {
    label.addEventListener('click', () => {
      const val = label.getAttribute('for').replace('star', '');
      const inp = document.getElementById('rating-value');
      if (inp) inp.value = val;
    });
  });
}

// ── Progress Update ──
async function updateProgress(courseId, progress) {
  const formData = new FormData();
  formData.append('progress', progress);
  try {
    const res = await fetch(`/progress/${courseId}`, { method: 'POST', body: formData });
    const data = await res.json();
    const bar = document.getElementById(`progress-fill-${courseId}`);
    const pct = document.getElementById(`progress-pct-${courseId}`);
    if (bar) bar.style.width = data.progress + '%';
    if (pct) pct.textContent = data.progress + '%';
    if (data.completed) {
      showToast('🎉 Course completed! Certificate issued!', 'success');
      setTimeout(() => location.reload(), 2000);
    } else {
      showToast(`Progress saved: ${data.progress}%`, 'success');
    }
  } catch (err) {
    showToast('Failed to save progress.', 'danger');
  }
}

// ── Bookmark Toggle ──
async function toggleBookmark(courseId, btn) {
  try {
    const res = await fetch(`/bookmark/${courseId}`, { method: 'POST' });
    const data = await res.json();
    if (data.status === 'saved') {
      btn.classList.add('bookmarked');
      btn.textContent = '🔖 Saved';
      showToast('Course bookmarked!', 'success');
    } else {
      btn.classList.remove('bookmarked');
      btn.textContent = '🔖 Bookmark';
      showToast('Bookmark removed', 'info');
    }
  } catch (err) {
    showToast('Failed to bookmark.', 'danger');
  }
}

// ── Notes Auto-Save ──
function initNotesAutoSave() {
  const notesArea = document.getElementById('notes-textarea');
  if (!notesArea) return;
  let timer;
  notesArea.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(() => saveNote(notesArea.dataset.courseId, notesArea.value), 1500);
  });
}

async function saveNote(courseId, content) {
  const formData = new FormData();
  formData.append('content', content);
  try {
    await fetch(`/note/${courseId}`, { method: 'POST', body: formData });
    showToast('📝 Note saved!', 'success');
  } catch (err) { }
}

// ── Toast ──
function showToast(message, type = 'info') {
  const colors = {
    success: { bg: '#d1fae5', text: '#065f46', border: '#6ee7b7' },
    danger:  { bg: '#fee2e2', text: '#991b1b', border: '#fca5a5' },
    info:    { bg: '#dbeafe', text: '#1e40af', border: '#93c5fd' },
    warning: { bg: '#fef3c7', text: '#92400e', border: '#fcd34d' }
  };
  const c = colors[type] || colors.info;
  const toast = document.createElement('div');
  toast.style.cssText = `
    position:fixed; bottom:1.5rem; right:1.5rem;
    background:${c.bg}; color:${c.text}; border:1px solid ${c.border};
    padding:0.8rem 1.2rem; border-radius:10px;
    box-shadow:0 4px 16px rgba(0,0,0,0.15);
    font-weight:600; font-size:0.88rem; z-index:9999;
    animation:slideInRight 0.3s ease; max-width:300px;
  `;
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    toast.style.transition = 'all 0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ── Counter Animation ──
function animateCounters() {
  document.querySelectorAll('.stat-number').forEach(el => {
    const target = parseInt(el.textContent) || 0;
    let current = 0;
    const step = Math.ceil(target / 30) || 1;
    const interval = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = current;
      if (current >= target) clearInterval(interval);
    }, 30);
  });
}

// ── Escape HTML ──
function escHtml(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Category Emoji ──
function getCategoryEmoji(cat) {
  const map = {
    'Programming':'💻','Data Science':'📊','Web Development':'🌐',
    'AI':'🧠','Security':'🔒','Cloud':'☁️','Mobile':'📱',
    'DevOps':'⚙️','Design':'🎨','Computer Science':'🖥️',
    'Blockchain':'⛓️','Statistics':'📈','Game Dev':'🎮',
    'Emerging Tech':'🚀','Business':'💼','Backend':'🔧',
    'Computer Vision':'👁️','Database':'🗄️'
  };
  return map[cat] || '📚';
}
